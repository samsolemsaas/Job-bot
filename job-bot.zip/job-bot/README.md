# Job Bot

Checks about 240 company job boards twice a day (7 am and 4 pm Pacific) and emails you only roles it hasn't shown you before. Each match lists title, compensation if posted, location and a direct link. Roles must be fully remote in the US or in Seattle, Bellevue, Kirkland or Redmond.

It reads boards on Greenhouse, Lever and Ashby through their official public job-board APIs. No LinkedIn, no scraping, no logins.

## Setup (about 20 minutes, easiest on a computer)

**1. Make a private repo.** Go to github.com/new. Name it `job-bot`, choose **Private**, tick **Add a README**, and create it.

**2. Upload the files.** In the repo, click **Add file → Upload files**. Drag in `job_bot.py`, `companies.txt` and the `state` folder. Commit.

**3. Add the schedule file.** Click **Add file → Create new file**. Type this exact name, slashes included: `.github/workflows/job-bot.yml`. Paste in the contents of `job-bot.yml` from this folder. Commit.

**4. Make a Gmail app password.** Go to myaccount.google.com → Security. Turn on 2-Step Verification if it isn't on. Then search the settings for **App passwords**, create one called `job bot`, and copy the 16-character code.

**5. Add two secrets.** In the repo, go to **Settings → Secrets and variables → Actions → New repository secret**. Add:
- `GMAIL_ADDRESS` = your Gmail address
- `GMAIL_APP_PASSWORD` = the 16-character code

Optional: `DIGEST_TO` if you want digests sent to a different address.

**6. Run it once.** Open the **Actions** tab, pick **Job bot**, click **Run workflow**. The first run takes 5 to 10 minutes while it finds each company's board, then sends a "first run" email with everything currently open. After that you only hear about new roles. No email means nothing new that day.

## Day to day

- **Add a company:** edit `companies.txt` in GitHub (pencil icon) and add a line.
- **Company not found:** check `state/not_found.txt`. Some companies use Workday, JazzHR or their own site, which the bot can't read yet. If you find their Ashby, Greenhouse or Lever page, add an override like `Company Name | ashby:slug`.
- **History:** `state/jobs_log.csv` keeps every match the bot has sent.
- **Change what counts as a match:** the keyword lists sit near the top of `job_bot.py`.
- **If a run breaks:** GitHub emails you about the failed run.

A listing that just says "Remote" gets labeled "confirm US eligibility" so you can check before applying.
